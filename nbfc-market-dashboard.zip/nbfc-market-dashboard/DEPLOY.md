# NBFC Market & Valuation — deploy to Netlify

Self-contained. Nothing to build, no npm install, no dependencies to fetch.

## Deploy

1. Go to **app.netlify.com** → log in.
2. Open the **Sites** tab.
3. Drag **this whole `nbfc-market-dashboard` folder** onto the drop zone that says
   *"Drag and drop your project output folder here"*.
4. Wait ~20 seconds. You get a URL like `https://random-name-123.netlify.app`.
5. Optional: **Site configuration → Change site name** to something like
   `nbfc-market`, giving you `https://nbfc-market.netlify.app`.

Send that URL to the MD. On an iPhone, Safari → Share → **Add to Home Screen**
makes it open full-screen like an app.

> **Drag the folder itself — not its contents, and not a zip of it.**
> Netlify needs to see `netlify.toml` and the `netlify/functions` folder sitting
> next to `index.html`, or live prices will not load.

## Checking it worked

Open the site. The **Prices** tab should show nine tiles with rupee prices.

If you instead see an orange banner saying *"the /api/yahoo function is not
deployed"*, the serverless function did not come across. Re-drag the folder and
confirm `netlify.toml` and `netlify/functions/yahoo.mjs` are inside it. You can
verify from the Netlify dashboard under **Site configuration → Functions** —
`yahoo` should be listed.

## Why there is a function at all

The browser cannot call Yahoo Finance directly — Yahoo sends no CORS headers, so
the request is blocked. `netlify/functions/yahoo.mjs` is a small server-side
pass-through to the same Yahoo endpoint the Python `yfinance` package uses, which
is what the main Streamlit dashboard reads. Both dashboards therefore show the
same numbers.

It only proxies the nine whitelisted NBFC tickers, and replies are cached at the
CDN (60s for intraday, 300s for daily history), so the page loads instantly and
Yahoo is not hammered.

## What is live vs baked in

- **Live on every load:** prices, day change, volume, market cap, and all price
  history / comparison charts.
- **Baked in at build time:** book value per share and trailing earnings, used for
  the P/B and P/E charts. These come from company filings and only change when a
  quarter is reported.

To refresh the fundamentals later, regenerate `assets/data.js` from the main repo
(`python market-dashboard/generate_data.py`) and rebuild this bundle with
`python market-dashboard/make_bundle.py`.

## Updating later

Drag the folder again onto the **same site** (Deploys tab → drag onto the drop
zone). It replaces the previous deploy and the URL stays the same.

If you would rather it update automatically on every push, connect the GitHub repo
instead: **Add new site → Import an existing project** → pick the repo → leave the
build command empty. The `netlify.toml` at the repo root already points Netlify at
the right folder.
