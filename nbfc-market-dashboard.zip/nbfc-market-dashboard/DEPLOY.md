# NBFC Market & Valuation — deploy to Netlify

Self-contained. Nothing to build, no npm install, no dependencies to fetch.

## Deploy

1. Go to **app.netlify.com** → log in.
2. Open the **Sites** tab.
3. Drag **this whole `nbfc-market-dashboard` folder** onto the drop zone that says
   *"Drag and drop your project output folder here"*.
4. Wait ~20 seconds. You get a URL like `https://random-name-123.netlify.app`.
5. Optional: **Site configuration → Change site name** to something like
   `nbfc-market`, giving you `https://nbfc-market.netlify.app`.

Send that URL to the MD. On an iPhone, Safari → Share → **Add to Home Screen**
makes it open full-screen like an app.

> **Drag the folder itself — not its contents, and not a zip of it.**
> Netlify needs to see `netlify.toml` and the `netlify/functions` folder sitting
> next to `index.html`, or live prices will not load.

## Checking it worked

Open the site. The **Prices** tab should list all nine companies with rupee prices.

If prices are missing, see the next section — it is almost certainly the feed, not
the deploy. You can confirm the function itself deployed under **Site configuration
→ Functions**, where `market` should be listed.

## Important: live prices need an API key

Yahoo Finance rate-limits cloud/datacenter IP addresses — which is exactly where
this function runs. It answers `HTTP 429` more or less permanently from Netlify,
even though the same request works from a home machine. (That is why the Streamlit
dashboard is unaffected: it runs on your own laptop.)

The fix is a free **Twelve Data** key. It is built to be called from servers and
carries all nine NSE tickers under identical codes.

1. Sign up at twelvedata.com (free tier: 800 API credits/day)
2. Netlify -> **Site configuration -> Environment variables -> Add**
3. Key `TWELVEDATA_API_KEY`, value your key
4. **Deploys -> Trigger deploy**

The function switches over automatically. A full trading day costs roughly 500 of
the 800 free daily credits.

**Without a key** the page falls back to the dated price snapshot baked into
`assets/data.js` and says so at the top. Book value, P/B and P/E still work
normally, because those come from filings rather than the live feed.

## What is live vs baked in

- **Live (with an API key):** prices, day change, volume, market cap and the
  window movement percentages.
- **Baked in:** book value per share and trailing earnings (used for P/B and P/E),
  plus a dated fallback price snapshot. These come from company filings and change
  only when a quarter is reported.

To refresh either, run these in the main repo and re-drag the folder:

```
python market-dashboard/bake_snapshot.py    # refresh the price snapshot
python market-dashboard/generate_data.py    # refresh book value / earnings
python market-dashboard/make_bundle.py      # rebuild this folder
```

## Updating later

Drag the folder again onto the **same site** (Deploys tab → drag onto the drop
zone). It replaces the previous deploy and the URL stays the same.

If you would rather it update automatically on every push, connect the GitHub repo
instead: **Add new site → Import an existing project** → pick the repo → leave the
build command empty. The `netlify.toml` at the repo root already points Netlify at
the right folder.
